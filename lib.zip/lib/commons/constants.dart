class Urls {
  static const String baseUrl = 'https://briefly-main-skylark.ngrok-free.app/logs';
}
