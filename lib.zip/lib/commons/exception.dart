class ServerException implements Exception {}
