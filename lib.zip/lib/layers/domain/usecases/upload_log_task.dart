import 'package:dartz/dartz.dart';
import '../../../commons/failure.dart';
import '../../data/models/log_model.dart';
import '../entities/Log.dart';
import '../repositories/remote_local_repository.dart';

class UploadLogTask {
  final RemoteRepository repository;

  UploadLogTask(this.repository);

  Future<Either<Failure, bool>> execute(String body) {
    return repository.uploadLogs(body);
  }
}
