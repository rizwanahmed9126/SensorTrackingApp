import 'dart:async';
import 'dart:convert';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

import '../../data/models/log_model.dart';
import '../../domain/usecases/upload_log_task.dart';
import '../../domain/usecases/local_storage_tasks.dart';

class HomeProvider extends ChangeNotifier{
  final LocalStorageTasks _localStorageTasks;
  final UploadLogTask _uploadLogTask;


  HomeProvider({
    required LocalStorageTasks localStorageTasks,
    required UploadLogTask uploadLogTask,

  }) : _uploadLogTask = uploadLogTask, _localStorageTasks = localStorageTasks;


  LogModel? logModel;
  bool isCompassEnabled = false;


  Timer? _timer;
  Timer? _timer2;
  void startTimer() async{
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) async{

      final result = await _localStorageTasks.getAndSaveLogLocal();
      result.fold((e) {
        print(e);
      }, (list) {
        logModel = list;

      },
      );
      notifyListeners();

    });
  }

  void pauseTimer() {
    if (_timer != null) {
      _timer!.cancel();
      _timer = null; // Set _timer to null to indicate it's paused/stopped
    }
    if (_timer2 != null) {
      _timer2!.cancel();
      _timer2 = null; // Set _timer to null to indicate it's paused/stopped
    }
  }




  void sendDataToServer() async{

    _timer2 = Timer.periodic(const Duration(minutes: 1), (timer) {
      processAndSendDataBatches();
    });
  }


  void toggleCompass() async{

      isCompassEnabled = !isCompassEnabled;

    if(isCompassEnabled){
      startTimer();
      sendDataToServer();
    }else{
      pauseTimer();
      processAndSendDataBatches();

    }
   notifyListeners();
  }



  Future<bool> uploadDataOnServer(String body) async {


    bool? result;


    // Fetch the list
    final response = await _uploadLogTask.execute(body);



    // Handle success or error
    response.fold((e) {
      result = false;
    }, (list) {
      result = true;
    },
    );

    return result ?? false;
    // notify UI
    notifyListeners();
  }

  Future<void> deleteLogs(List<int> ids)async {
    String? data;
    final fetched = await _localStorageTasks.deleteLogs(ids);
    // Handle success or error
    fetched.fold((e) {
      print("fail to delete logs");
    }, (list) {

      print("deleted logs");
    },
    );

   // return data ?? 'null';

  }

  Future<String> getLogs()async {
    String? data;
    final fetched = await _localStorageTasks.showLogs();
    // Handle success or error
    fetched.fold((e) {
      print("fail to fetch logs");
    }, (list) {
      data = list;
      print(fetched);
    },
    );

    return data ?? 'null';

  }




  void startConnectivityListener() {
    var connectivity = Connectivity();
    ConnectivityResult? previousResult;


    connectivity.onConnectivityChanged.listen((ConnectivityResult result) {

      if (previousResult == ConnectivityResult.none && result != ConnectivityResult.none) {
        processAndSendDataBatches();
      }

      previousResult = result;


    });
  }



  Future<void> processAndSendDataBatches()  async{
    print("I have been called");
    bool hasMoreData = true;
    final connectivityResult = await (Connectivity().checkConnectivity());

    if (connectivityResult != ConnectivityResult.none){
      while (hasMoreData) {
        String jsonLogs = await getLogs();
        List<dynamic> logList = jsonDecode(jsonLogs);
        print("i am here");


        if (logList.isNotEmpty) {

          var result = await uploadDataOnServer(jsonLogs);
          if(result){
            List<int> sentLogIds = logList.map((log) => log['id'] as int).toList();
            await deleteLogs(sentLogIds);
          }



        } else {

          hasMoreData = false;
          break;// No more data to send
        }
      }
    }
    else{
      print("not connected to any network");
    }



  }

}