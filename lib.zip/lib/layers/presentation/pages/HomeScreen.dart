//
// import 'dart:async';
// import 'dart:convert';
// import 'dart:math' as math;
//
// import 'package:flutter/material.dart';
// import 'package:flutter_compass/flutter_compass.dart';
// import 'package:get_it/get_it.dart';
// import 'package:path/path.dart';
// import 'package:permission_handler/permission_handler.dart';
// import 'package:http/http.dart' as http;
// import 'package:provider/provider.dart';
// import 'package:sensor_tracking_app/layers/presentation/notifiers/home_provider.dart';
// import 'package:sqflite/sqflite.dart';
//
//
//
//
//
//
//
//
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({
//     Key? key,
//   }) : super(key: key);
//
//   @override
//   _HomeScreenState createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   bool _hasPermissions = false;
//   CompassEvent? _lastRead;
//   DateTime? _lastReadAt;
//
//   readData()async{
//     final CompassEvent tmp = await FlutterCompass.events!.first;
//     setState(() {
//       _lastRead = tmp;
//       _lastReadAt = DateTime.now().toUtc();
//     });
//
//     var fido =  Log(
//       reading: _lastRead!.heading!,
//       readAt: _lastReadAt.toString(),
//     );
//     await insertLog(fido);
//   }
//   var database;
//
//   void method()async{
//     database = openDatabase(
//       join(await getDatabasesPath(), 'loggie1_database.db'),
//       onCreate: (db, version) {
//         return db.execute(
//           'CREATE TABLE logs(id INTEGER PRIMARY KEY AUTOINCREMENT, reading REAL, readAt TEXT)',
//         );
//       },
//       version: 1,
//     );
//
//   }
//
//
//
//   Future<void> processAndSendDataBatches() async {
//     int batchNumber = 4;
//     const int batchSize = 10;
//     bool hasMoreData = true;
//
//     while (hasMoreData) {
//       String jsonLogs = await showLogs(batchNumber, batchSize);
//       List<dynamic> logList = jsonDecode(jsonLogs);
//       print("i am here");
//
//
//       if (logList.isNotEmpty) {
//
//
//         var headers = {'Content-Type': 'application/json'};
//         var request = http.Request('POST', Uri.parse('https://briefly-main-skylark.ngrok-free.app/logs'));
//         request.body = jsonLogs;
//         request.headers.addAll(headers);
//
//         http.StreamedResponse response = await request.send();
//
//         if (response.statusCode == 201) {
//           print('Batch $batchNumber sent successfully');
//           // Delete sent logs from the database
//           List<int> sentLogIds = logList.map((log) => log['id'] as int).toList();
//           await deleteLog(sentLogIds);
//         } else {
//           print('Failed to send batch $batchNumber: ${response.reasonPhrase}');
//           break; // Or handle the error based on your requirements
//         }
//
//         batchNumber++;
//       } else {
//
//         hasMoreData = false;
//         break;// No more data to send
//       }
//     }
//   }
//
//
//
//
//
//   // Define a function that inserts logs into the database
//   Future<void> insertLog(Log log) async {
//     final db = await database;
//     await db.insert(
//       'logs',
//       log.toMap(),
//       conflictAlgorithm: ConflictAlgorithm.replace,
//     );
//   }
//
//   // A method that retrieves all the logs from the logs table.
//   Future<String> showLogs(int batchNumber, int batchSize) async {
//     final db = await database;
//     int offset = (batchNumber - 1) * batchSize;
//
//
//     final List<Map<String, dynamic>> maps = await db.query('logs',
//       limit: batchSize,
//       // offset: offset,
//     );
//
//
//     List<Log> logs = List.generate(maps.length, (i) {
//       return Log(
//         id: maps[i]['id'] as int?,
//         reading: maps[i]['reading'] as double,
//         readAt: maps[i]['readAt'] as String,
//       );
//     });
//
//     List< dynamic> jsonList = logs.map((log) => log.toMap()).toList();
//     String jsonString = jsonEncode(jsonList);
//
//     print(jsonString);
//     return jsonString;
//
//
//   }
//
//
//   Future<void> deleteLog(List<int> ids) async {
//     // final db = await database;
//     // await db.delete(
//     //   'logs',
//     //   where: 'id = ?',
//     //   whereArgs: [id],
//     // );
//
//     final db = await database;
//     for (var id in ids) {
//       await db.delete(
//         'logs',
//         where: 'id = ?',
//         whereArgs: [id],
//       );
//     }
//   }
//
//   @override
//   void initState() {
//     super.initState();
//
//
//     Permission.locationWhenInUse.request();
//
//
//
//     //method();
//    // _fetchPermissionStatus();
//
//     //_toggleCompass();
//    // sendDataToServer();
//
//     // Timer.periodic(const Duration(seconds: 1), (timer) {
//     //
//     //   readData();
//     // });
//
//   }
//
//
//
//   Timer? _timer;
//   void sendDataToServer() {
//     _timer = Timer.periodic(const Duration(minutes: 1), (timer) {
//       processAndSendDataBatches();
//     });
//   }
//
//   void startTimer() {
//     _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
//       readData();
//     });
//   }
//
//   void pauseTimer() {
//     if (_timer != null) {
//       _timer!.cancel();
//       _timer = null; // Set _timer to null to indicate it's paused/stopped
//     }
//   }
//
//
//
//
//   bool _isCompassEnabled = true;
//
//   void _toggleCompass() {
//     setState(() {
//       _isCompassEnabled = !_isCompassEnabled;
//     });
//     if(_isCompassEnabled){
//       startTimer();
//     }else{
//       pauseTimer();
//     }
//
//   }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//
//     return MaterialApp(
//       home: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: const Text('Flutter Compass'),
//         ),
//         body: Builder(builder: (context) {
//           if (_hasPermissions) {
//             return
//               //   Center(
//               //   child: Column(
//               //     mainAxisAlignment: MainAxisAlignment.center,
//               //     children: <Widget>[
//               //       Text('Heading: ${_lastRead?.heading}'),
//               //       Switch(
//               //         value: _isCompassEnabled,
//               //         onChanged: (value) {
//               //           _toggleCompass();
//               //         },
//               //       ),
//               //     ],
//               //   ),
//               // );
//
//
//               Consumer<HomeProvider>(
//                 builder: (context, value, child) {
//               return Column(
//                 children: <Widget>[
//                   _buildManualReader(context,value.logModel?.reading??0,value.logModel?.readAt??''),
//
//                   Switch(
//                     value: value.isCompassEnabled,
//                     onChanged: (vl) {
//                       value.toggleCompass();
//                     },
//                   ),
//                   // Expanded(child: _buildCompass()),
//                 ],
//               );
//             });
//
//
//
//
//
//           } else {
//             return _buildPermissionSheet();
//           }
//         }),
//       ),
//     );
//   }
//
//
//   Future<List<String>> getAllTableNames() async {
// // you can use your initial name for dbClient
//
//     final db = await database;
//     List<Map> maps =
//     await db.rawQuery('SELECT * FROM sqlite_master ORDER BY name;');
//
//     List<String> tableNameList = [];
//     if (maps.length > 0) {
//       for (int i = 0; i < maps.length; i++) {
//         try {
//           tableNameList.add(maps[i]['name'].toString());
//         } catch (e) {
//           print('Exeption : $e');
//         }
//       }
//     }
//     tableNameList.forEach((element) {
//       print(element);
//     });
//     return tableNameList;}
//
//   Widget _buildManualReader(context, double heading,String dateTime) {
//     return Padding(
//       padding: const EdgeInsets.all(16.0),
//       child: Row(
//         children: <Widget>[
//           ElevatedButton(
//             child: Text('Read Value'),
//             onPressed: () async {
//              // Provider.of<LocalDataNotifier>(context,listen: false).getLogs();
//
//
//
//
//               //getAllTableNames();
//
//               // var fido =  Log(
//               //   reading: _lastRead!.heading!,
//               //   readAt: _lastReadAt.toString(),
//               // );
//               //  await insertLog(fido);
//
//               List<int> id = [60,61,75,76,77];
//                await deleteLog(id);
//               //processAndSendDataBatches();
//                String logs =  await showLogs(3,10);
//
//
//
//
//
//
//               // var headers = {
//               //   'Content-Type': 'application/json'
//               // };
//               // var request = http.Request('POST', Uri.parse('https://briefly-main-skylark.ngrok-free.app/logs'));
//               // request.body = logs;
//               // request.headers.addAll(headers);
//               //
//               // http.StreamedResponse response = await request.send();
//               //
//               // if (response.statusCode == 200) {
//               //   print(await response.stream.bytesToString());
//               // }
//               // else {
//               //   print(response.reasonPhrase);
//               // }
//               //
//               //
//
//
//
//
//
//
//
//
//
//             },
//           ),
//           Expanded(
//             child: Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: <Widget>[
//                   Text(
//                     '${heading}'//'${_lastRead?.heading}',
//                     // style: Theme.of(context).textTheme.bodySmall,
//                   ),
//                   Text(
//                       '${dateTime}'//'$_lastReadAt',
//                     // style: Theme.of(context).textTheme.bodySmall,
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//
//
//
//
//
//   Widget _buildCompass() {
//     return StreamBuilder<CompassEvent>(
//       stream: FlutterCompass.events,
//       builder: (context, snapshot) {
//         if (snapshot.hasError) {
//           return Text('Error reading heading: ${snapshot.error}');
//         }
//
//         if (snapshot.connectionState == ConnectionState.waiting) {
//           return const Center(
//             child: CircularProgressIndicator(),
//           );
//         }
//
//         double? direction = snapshot.data!.heading;
//
//         // if direction is null, then device does not support this sensor
//         // show error message
//         if (direction == null)
//           return Center(
//             child: Text("Device does not have sensors !"),
//           );
//
//         return Material(
//           shape: CircleBorder(),
//           clipBehavior: Clip.antiAlias,
//           elevation: 4.0,
//           child: Container(
//             padding: EdgeInsets.all(16.0),
//             alignment: Alignment.center,
//             decoration: BoxDecoration(
//               shape: BoxShape.circle,
//             ),
//             child: Transform.rotate(
//               angle: (direction * (math.pi / 180) * -1),
//               child: Image.asset('assets/compass.jpg'),
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   Widget _buildPermissionSheet() {
//     return Center(
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: <Widget>[
//           Text('Location Permission Required'),
//           ElevatedButton(
//             child: Text('Request Permissions'),
//             onPressed: () {
//               Permission.locationWhenInUse.request().then((ignored) {
//                 _fetchPermissionStatus();
//               });
//             },
//           ),
//           SizedBox(height: 16),
//           ElevatedButton(
//             child: Text('Open App Settings'),
//             onPressed: () {
//               openAppSettings().then((opened) {
//                 //
//               });
//             },
//           )
//         ],
//       ),
//     );
//   }
//
//   void _fetchPermissionStatus() {
//     Permission.locationWhenInUse.status.then((status) {
//       if (mounted) {
//         setState(() => _hasPermissions = status == PermissionStatus.granted);
//       }
//     });
//   }
//
//
//
//
//
//
//
//
//
// }
//
//
//
//
// class Log {
//   final int? id;
//
//   final double reading;
//   final String readAt;
//
//   const Log({
//     this.id,
//     required this.reading,
//     required this.readAt,
//   });
//
//   Map<String, dynamic> toMap() {
//     return {
//       'id' : id,
//       'reading': reading,
//       'readAt': readAt,
//     };
//   }
//
//   @override
//   String toString() {
//     return '{id: $id, reading: $reading, readAt: $readAt}';
//   }
// }
//
//
//
//
