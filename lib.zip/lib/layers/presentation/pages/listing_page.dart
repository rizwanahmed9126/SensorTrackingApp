
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sensor_tracking_app/layers/presentation/notifiers/home_provider.dart';


class ListingPage extends StatefulWidget {
  const ListingPage({Key? key}) : super(key: key);
  @override
  _HomePageState createState() => _HomePageState();
}
class _HomePageState extends State<ListingPage> {



  @override
  void initState() {
    context.read<HomeProvider>().startConnectivityListener();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Sensor Tracking App"),
      ),
      body: Builder(builder: (context) {
       // if (_hasPermissions) {
          return Consumer<HomeProvider>(
                builder: (context, value, child) {
                  return Column(
                    children: <Widget>[
                      _buildManualReader(context,value.logModel?.reading??0,value.logModel?.readAt??''),

                      Switch(
                        value: value.isCompassEnabled,
                        onChanged: (vl) {
                          value.toggleCompass();
                        },
                      ),
                      // Expanded(child: _buildCompass()),
                    ],
                  );
                });

      }),
    );
  }

  Widget _buildManualReader(context, double heading,String dateTime) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: <Widget>[
          ElevatedButton(
            child: Text('Read Value'),
            onPressed: () async {
              Provider.of<HomeProvider>(context,listen: false).getLogs();




              //getAllTableNames();

              // var fido =  Log(
              //   reading: _lastRead!.heading!,
              //   readAt: _lastReadAt.toString(),
              // );
              //  await insertLog(fido);

              // List<int> id = [60,61,75,76,77];
              //  await deleteLog(id);
              //processAndSendDataBatches();
              // String logs =  await showLogs(3,10);






              // var headers = {
              //   'Content-Type': 'application/json'
              // };
              // var request = http.Request('POST', Uri.parse('https://briefly-main-skylark.ngrok-free.app/logs'));
              // request.body = logs;
              // request.headers.addAll(headers);
              //
              // http.StreamedResponse response = await request.send();
              //
              // if (response.statusCode == 200) {
              //   print(await response.stream.bytesToString());
              // }
              // else {
              //   print(response.reasonPhrase);
              // }
              //
              //









            },
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                      '${heading}'//'${_lastRead?.heading}',
                    // style: Theme.of(context).textTheme.bodySmall,
                  ),
                  Text(
                      '${dateTime}'//'$_lastReadAt',
                    // style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

}

